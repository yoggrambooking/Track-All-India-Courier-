/**
 * GOOGLE FORM & SPREADSHEET INTEGRATION CONFIGURATION
 * 
 * Replace the values below with your own Google Form URL to automatically collect
 * all shipment tracking enquiries in your Google Sheets database.
 * 
 * =========================================================================
 * HOW TO CONNECT WITH GOOGLE FORM & GOOGLE SHEETS IN 3 STEPS:
 * =========================================================================
 * 1. Create a Google Form with 5 Short Answer fields:
 *    - Full Name
 *    - Mobile Number
 *    - Courier Company
 *    - Tracking ID / AWB Number
 *    - Shipment Location
 * 
 * 2. In Google Form, click Responses -> "Link to Sheets" to send data to Google Sheets.
 * 
 * 3. Copy your Google Form URL:
 *    - If using Direct Form POST:
 *      Use: https://docs.google.com/forms/d/e/[FORM_ID]/formResponse
 *      and fill the entry IDs below (get them by clicking "Get pre-filled link").
 *    - Or if using Embed mode:
 *      Simply paste the Google Form link into GOOGLE_FORM_URL below.
 */

export const GOOGLE_FORM_CONFIG = {
  /**
   * PASTE YOUR GOOGLE FORM SUBMIT OR EMBED URL HERE
   * Example: "https://docs.google.com/forms/d/e/1FAIpQLSc.../formResponse"
   */
  GOOGLE_FORM_URL: "PASTE_YOUR_GOOGLE_FORM_URL_HERE",

  /**
   * (Optional) Field Entry IDs for direct background submission.
   * If left default, the app simulates seamless submission and logs locally.
   */
  ENTRIES: {
    fullName: "entry.1000001",
    mobileNumber: "entry.1000002",
    courierCompany: "entry.1000003",
    trackingId: "entry.1000004",
    shipmentLocation: "entry.1000005",
  },

  /**
   * Enable direct iframe embed fallback tab if configured
   */
  ALLOW_IFRAME_FALLBACK: true,
};

export interface ShipmentEnquiryPayload {
  referenceId: string;
  fullName: string;
  mobileNumber: string;
  courierCompany: string;
  courierId: string;
  trackingId: string;
  shipmentLocation: string;
  submittedAt: string;
  status: 'Received' | 'In Review' | 'Processed';
}

/**
 * Handles submission to Google Forms (if configured) or records locally
 */
export async function submitShipmentEnquiry(
  payload: ShipmentEnquiryPayload
): Promise<{ success: boolean; mode: 'google_form' | 'local_storage'; referenceId: string }> {
  const isGoogleFormConfigured =
    GOOGLE_FORM_CONFIG.GOOGLE_FORM_URL &&
    !GOOGLE_FORM_CONFIG.GOOGLE_FORM_URL.includes("PASTE_YOUR_GOOGLE_FORM_URL_HERE");

  if (isGoogleFormConfigured) {
    try {
      // Build form data URL parameters
      const formUrl = GOOGLE_FORM_CONFIG.GOOGLE_FORM_URL;
      const params = new URLSearchParams();
      params.append(GOOGLE_FORM_CONFIG.ENTRIES.fullName, payload.fullName);
      params.append(GOOGLE_FORM_CONFIG.ENTRIES.mobileNumber, payload.mobileNumber);
      params.append(GOOGLE_FORM_CONFIG.ENTRIES.courierCompany, payload.courierCompany);
      params.append(GOOGLE_FORM_CONFIG.ENTRIES.trackingId, payload.trackingId);
      params.append(GOOGLE_FORM_CONFIG.ENTRIES.shipmentLocation, payload.shipmentLocation);

      // Attempt background submit via no-cors mode to avoid browser CORS blocks on Google Forms
      await fetch(formUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: params.toString(),
      });

      // Save copy to local storage history
      saveToLocalHistory(payload);

      return { success: true, mode: 'google_form', referenceId: payload.referenceId };
    } catch (err) {
      console.warn("Could not post directly to Google Form, saving to local state:", err);
      saveToLocalHistory(payload);
      return { success: true, mode: 'local_storage', referenceId: payload.referenceId };
    }
  }

  // If placeholder remains, save cleanly to localStorage for demo & offline persistence
  saveToLocalHistory(payload);
  return { success: true, mode: 'local_storage', referenceId: payload.referenceId };
}

function saveToLocalHistory(payload: ShipmentEnquiryPayload) {
  try {
    const existing = localStorage.getItem('courier_search_enquiries');
    const list: ShipmentEnquiryPayload[] = existing ? JSON.parse(existing) : [];
    list.unshift(payload);
    // Keep max 20 recent
    localStorage.setItem('courier_search_enquiries', JSON.stringify(list.slice(0, 20)));
  } catch (e) {
    console.error("Local storage error:", e);
  }
}

export function getLocalEnquiries(): ShipmentEnquiryPayload[] {
  try {
    const existing = localStorage.getItem('courier_search_enquiries');
    return existing ? JSON.parse(existing) : [];
  } catch {
    return [];
  }
}
