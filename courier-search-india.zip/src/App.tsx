/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { TrustFeatures } from './components/TrustFeatures';
import { HowItWorks } from './components/HowItWorks';
import { SupportedCarriersSection } from './components/SupportedCarriersSection';
import { RecentEnquiries } from './components/RecentEnquiries';
import { Footer } from './components/Footer';
import { SubmissionSuccessModal } from './components/SubmissionSuccessModal';
import {
  PrivacyModal,
  TermsModal,
  DisclaimerModal,
  ContactModal,
  GoogleFormGuideModal,
} from './components/Modals/LegalModals';
import { ShipmentEnquiryPayload } from './config/googleForm';
import { CourierCompany } from './data/couriers';

export default function App() {
  // Modal states
  const [successData, setSuccessData] = useState<ShipmentEnquiryPayload | null>(null);
  const [isPrivacyOpen, setIsPrivacyOpen] = useState(false);
  const [isTermsOpen, setIsTermsOpen] = useState(false);
  const [isDisclaimerOpen, setIsDisclaimerOpen] = useState(false);
  const [isContactOpen, setIsContactOpen] = useState(false);
  const [isGuideOpen, setIsGuideOpen] = useState(false);

  const [selectedCourierId, setSelectedCourierId] = useState<string | null>(null);

  // History refresh trigger
  const [lastUpdated, setLastUpdated] = useState<number>(Date.now());

  const handleSubmissionSuccess = (payload: ShipmentEnquiryPayload) => {
    setSuccessData(payload);
    setLastUpdated(Date.now());
  };

  const handleResetSubmission = () => {
    setSuccessData(null);
    setSelectedCourierId(null);
    const cardEl = document.getElementById('track-card');
    if (cardEl) {
      cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const scrollToTrack = () => {
    const cardEl = document.getElementById('track-card');
    if (cardEl) {
      cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const scrollToHowItWorks = () => {
    const el = document.getElementById('how-it-works');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800 font-sans selection:bg-blue-600 selection:text-white">
      {/* Top Header */}
      <Header
        onOpenContact={() => setIsContactOpen(true)}
        onOpenGuide={() => setIsGuideOpen(true)}
        onTrackClick={scrollToTrack}
        onHowItWorksClick={scrollToHowItWorks}
      />

      {/* Main Content */}
      <main className="flex-1">
        {/* Hero Section with Search Shipment Card */}
        <HeroSection
          onSuccess={handleSubmissionSuccess}
          onSelectCourierPrompt={scrollToTrack}
          preselectedCourierId={selectedCourierId}
        />

        {/* 4 Trust Features */}
        <TrustFeatures />

        {/* How It Works (5 Steps) */}
        <HowItWorks />

        {/* Supported Carriers Directory */}
        <SupportedCarriersSection
          onSelectCourier={(courier: CourierCompany) => {
            setSelectedCourierId(courier.id);
            scrollToTrack();
          }}
        />

        {/* User's Local Enquiries History */}
        <RecentEnquiries lastUpdated={lastUpdated} />
      </main>

      {/* Footer with Independent Disclaimer */}
      <Footer
        onOpenPrivacy={() => setIsPrivacyOpen(true)}
        onOpenTerms={() => setIsTermsOpen(true)}
        onOpenDisclaimer={() => setIsDisclaimerOpen(true)}
        onOpenContact={() => setIsContactOpen(true)}
        onOpenGuide={() => setIsGuideOpen(true)}
        onTrackClick={scrollToTrack}
        onHowItWorksClick={scrollToHowItWorks}
      />

      {/* Submission Confirmation Modal */}
      {successData && (
        <SubmissionSuccessModal
          data={successData}
          onReset={handleResetSubmission}
        />
      )}

      {/* Legal & Policy Modals */}
      <PrivacyModal
        isOpen={isPrivacyOpen}
        onClose={() => setIsPrivacyOpen(false)}
      />
      <TermsModal
        isOpen={isTermsOpen}
        onClose={() => setIsTermsOpen(false)}
      />
      <DisclaimerModal
        isOpen={isDisclaimerOpen}
        onClose={() => setIsDisclaimerOpen(false)}
      />
      <ContactModal
        isOpen={isContactOpen}
        onClose={() => setIsContactOpen(false)}
      />
      <GoogleFormGuideModal
        isOpen={isGuideOpen}
        onClose={() => setIsGuideOpen(false)}
      />
    </div>
  );
}

