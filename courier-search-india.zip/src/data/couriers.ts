/**
 * Courier Company Database
 * Editable registry of courier, logistics, and e-commerce companies operating in India.
 * Includes visual brand marks, categories, tracking ID formats, and quick search aliases.
 */

export interface CourierCompany {
  id: string;
  name: string;
  shortName?: string;
  category: 'popular' | 'ecommerce' | 'express' | 'cargo' | 'international' | 'regional' | 'other';
  brandColor: string;
  badgeTextColor: string;
  initials: string;
  searchKeywords: string[];
  sampleFormat: string;
  popular?: boolean;
}

export const COURIER_DATABASE: CourierCompany[] = [
  // Top Popular Indian Couriers
  {
    id: 'delhivery',
    name: 'Delhivery',
    shortName: 'Delhivery',
    category: 'popular',
    brandColor: '#B91C1C', // Deep red
    badgeTextColor: '#FFFFFF',
    initials: 'DLV',
    searchKeywords: ['delhivery', 'del', 'express', 'surface'],
    sampleFormat: '12-14 digits (e.g. 128372619283)',
    popular: true,
  },
  {
    id: 'bluedart',
    name: 'Blue Dart',
    shortName: 'Blue Dart',
    category: 'popular',
    brandColor: '#002B7F', // Blue Dart Navy
    badgeTextColor: '#FFFFFF',
    initials: 'BD',
    searchKeywords: ['blue dart', 'bluedart', 'blue', 'dart', 'dhl'],
    sampleFormat: '8-11 digits (e.g. 3491827419)',
    popular: true,
  },
  {
    id: 'dtdc',
    name: 'DTDC',
    shortName: 'DTDC',
    category: 'popular',
    brandColor: '#0047AB', // DTDC cobalt blue
    badgeTextColor: '#FFFFFF',
    initials: 'DTDC',
    searchKeywords: ['dtdc', 'desk to desk', 'express'],
    sampleFormat: 'Alpha-numeric (e.g. D12345678, B7654321)',
    popular: true,
  },
  {
    id: 'indiapost',
    name: 'India Post',
    shortName: 'India Post',
    category: 'popular',
    brandColor: '#C41230', // India Post Red
    badgeTextColor: '#FFFFFF',
    initials: 'IP',
    searchKeywords: ['india post', 'dak', 'post office', 'postal', 'bharat dak'],
    sampleFormat: '13 chars (e.g. EM123456789IN)',
    popular: true,
  },
  {
    id: 'speedpost',
    name: 'Speed Post',
    shortName: 'Speed Post',
    category: 'popular',
    brandColor: '#E65100', // Speed post amber
    badgeTextColor: '#FFFFFF',
    initials: 'SP',
    searchKeywords: ['speed post', 'speed', 'india post speed', 'ems'],
    sampleFormat: '13 chars (e.g. ED987654321IN)',
    popular: true,
  },
  {
    id: 'amazon',
    name: 'Amazon',
    shortName: 'Amazon',
    category: 'ecommerce',
    brandColor: '#FF9900', // Amazon orange
    badgeTextColor: '#111827',
    initials: 'AMZ',
    searchKeywords: ['amazon', 'ama', 'amzn', 'ats'],
    sampleFormat: 'Order or TBA ID (e.g. TBA1234567890)',
    popular: true,
  },
  {
    id: 'amazon-shipping',
    name: 'Amazon Shipping',
    shortName: 'Amazon Shipping',
    category: 'ecommerce',
    brandColor: '#232F3E', // Amazon Dark
    badgeTextColor: '#FFFFFF',
    initials: 'ATS',
    searchKeywords: ['amazon shipping', 'ats', 'amazon logistics', 'amzn ship'],
    sampleFormat: 'AWB (e.g. IND123456789)',
    popular: true,
  },
  {
    id: 'flipkart',
    name: 'Flipkart',
    shortName: 'Flipkart',
    category: 'ecommerce',
    brandColor: '#2874F0', // Flipkart Blue
    badgeTextColor: '#FFFFFF',
    initials: 'FK',
    searchKeywords: ['flipkart', 'flip', 'fk', 'ekart'],
    sampleFormat: 'OD / FMPC ID (e.g. OD123456789)',
    popular: true,
  },
  {
    id: 'ekart',
    name: 'Ekart Logistics',
    shortName: 'Ekart',
    category: 'ecommerce',
    brandColor: '#0083CA', // Ekart Blue
    badgeTextColor: '#FFFFFF',
    initials: 'EKT',
    searchKeywords: ['ekart', 'ekart logistics', 'flipkart ekart', 'fmpc'],
    sampleFormat: 'Alpha-numeric (e.g. FMPC123456789)',
    popular: true,
  },
  {
    id: 'ecom-express',
    name: 'Ecom Express',
    shortName: 'Ecom Express',
    category: 'popular',
    brandColor: '#1A365D', // Navy
    badgeTextColor: '#FFFFFF',
    initials: 'ECOM',
    searchKeywords: ['ecom express', 'ecom', 'ee'],
    sampleFormat: '9-10 digits (e.g. 8491827364)',
    popular: true,
  },
  {
    id: 'xpressbees',
    name: 'XpressBees',
    shortName: 'XpressBees',
    category: 'popular',
    brandColor: '#F59E0B', // Amber
    badgeTextColor: '#111827',
    initials: 'XB',
    searchKeywords: ['xpressbees', 'xpress', 'bees', 'xb'],
    sampleFormat: '14 digits (e.g. 14238592019482)',
    popular: true,
  },
  {
    id: 'shadowfax',
    name: 'Shadowfax',
    shortName: 'Shadowfax',
    category: 'popular',
    brandColor: '#10B981', // Emerald
    badgeTextColor: '#FFFFFF',
    initials: 'SFX',
    searchKeywords: ['shadowfax', 'shadow', 'sfx'],
    sampleFormat: 'Alpha-numeric (e.g. SFX10928374)',
    popular: true,
  },
  {
    id: 'shiprocket',
    name: 'Shiprocket',
    shortName: 'Shiprocket',
    category: 'popular',
    brandColor: '#7C3AED', // Purple
    badgeTextColor: '#FFFFFF',
    initials: 'SR',
    searchKeywords: ['shiprocket', 'sr', 'rocket'],
    sampleFormat: 'SR AWB (e.g. SR12938475)',
    popular: true,
  },
  {
    id: 'shiprocket-x',
    name: 'Shiprocket X',
    shortName: 'Shiprocket X',
    category: 'international',
    brandColor: '#4F46E5', // Indigo
    badgeTextColor: '#FFFFFF',
    initials: 'SRX',
    searchKeywords: ['shiprocket x', 'cross border', 'srx'],
    sampleFormat: 'SRX Tracking (e.g. SRX83920184)',
  },
  {
    id: 'professional-couriers',
    name: 'The Professional Couriers',
    shortName: 'Professional Couriers',
    category: 'express',
    brandColor: '#1E3A8A', // Dark Blue
    badgeTextColor: '#FFFFFF',
    initials: 'TPC',
    searchKeywords: ['the professional couriers', 'tpc', 'professional courier'],
    sampleFormat: 'Consignment No (e.g. BOM123456789)',
    popular: true,
  },
  {
    id: 'gati',
    name: 'Gati',
    shortName: 'Gati',
    category: 'cargo',
    brandColor: '#047857', // Forest green
    badgeTextColor: '#FFFFFF',
    initials: 'GATI',
    searchKeywords: ['gati', 'gati kwep', 'allcargo'],
    sampleFormat: 'Docket No (e.g. 987654321)',
  },
  {
    id: 'safexpress',
    name: 'Safexpress',
    shortName: 'Safexpress',
    category: 'cargo',
    brandColor: '#B45309', // Rust
    badgeTextColor: '#FFFFFF',
    initials: 'SAFE',
    searchKeywords: ['safexpress', 'safe express', 'cargo'],
    sampleFormat: 'Waybill No (e.g. 10293847)',
  },
  {
    id: 'tci-express',
    name: 'TCI Express',
    shortName: 'TCI Express',
    category: 'cargo',
    brandColor: '#0E7490', // Cyan
    badgeTextColor: '#FFFFFF',
    initials: 'TCI',
    searchKeywords: ['tci express', 'tci', 'transport corporation'],
    sampleFormat: 'Docket No (e.g. 483920183)',
  },
  {
    id: 'vrl-logistics',
    name: 'VRL Logistics',
    shortName: 'VRL Logistics',
    category: 'cargo',
    brandColor: '#BE185D', // Pinkish red
    badgeTextColor: '#FFFFFF',
    initials: 'VRL',
    searchKeywords: ['vrl logistics', 'vrl', 'vijayanand roadlines'],
    sampleFormat: 'LR Number (e.g. 9283746)',
  },
  {
    id: 'trackon',
    name: 'Trackon',
    shortName: 'Trackon',
    category: 'express',
    brandColor: '#EA580C', // Orange
    badgeTextColor: '#FFFFFF',
    initials: 'TRK',
    searchKeywords: ['trackon', 'track on', 'prime track'],
    sampleFormat: 'Consignment No (e.g. 501928374)',
  },
  {
    id: 'shree-maruti',
    name: 'Shree Maruti Courier',
    shortName: 'Shree Maruti',
    category: 'regional',
    brandColor: '#DC2626', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'SMC',
    searchKeywords: ['shree maruti courier', 'maruti', 'smc'],
    sampleFormat: '10 digits (e.g. 7192837465)',
  },
  {
    id: 'madhur-courier',
    name: 'Madhur Courier',
    shortName: 'Madhur Courier',
    category: 'regional',
    brandColor: '#4338CA', // Indigo
    badgeTextColor: '#FFFFFF',
    initials: 'MDR',
    searchKeywords: ['madhur courier', 'madhur'],
    sampleFormat: 'Receipt No (e.g. 29384716)',
  },
  {
    id: 'st-courier',
    name: 'ST Courier',
    shortName: 'ST Courier',
    category: 'regional',
    brandColor: '#059669', // Emerald
    badgeTextColor: '#FFFFFF',
    initials: 'ST',
    searchKeywords: ['st courier', 'south india st'],
    sampleFormat: 'LR / AWB (e.g. ST8392018)',
  },
  {
    id: 'overnite-express',
    name: 'Overnite Express',
    shortName: 'Overnite Express',
    category: 'express',
    brandColor: '#9333EA', // Purple
    badgeTextColor: '#FFFFFF',
    initials: 'ONE',
    searchKeywords: ['overnite express', 'overnight'],
    sampleFormat: 'Consignment No (e.g. 192837465)',
  },
  {
    id: 'smartr-logistics',
    name: 'Smartr Logistics',
    shortName: 'Smartr',
    category: 'express',
    brandColor: '#2563EB', // Blue
    badgeTextColor: '#FFFFFF',
    initials: 'SMT',
    searchKeywords: ['smartr logistics', 'smartr'],
    sampleFormat: 'AWB (e.g. SMRT1293847)',
  },
  {
    id: 'loadshare',
    name: 'Loadshare',
    shortName: 'Loadshare',
    category: 'express',
    brandColor: '#D97706', // Gold
    badgeTextColor: '#111827',
    initials: 'LDS',
    searchKeywords: ['loadshare', 'load share'],
    sampleFormat: 'Waybill (e.g. LS83920194)',
  },
  {
    id: 'porter',
    name: 'Porter',
    shortName: 'Porter',
    category: 'regional',
    brandColor: '#0284C7', // Sky
    badgeTextColor: '#FFFFFF',
    initials: 'PTR',
    searchKeywords: ['porter', 'porter intra city'],
    sampleFormat: 'Order ID (e.g. CRN1029384)',
  },
  {
    id: 'dhl',
    name: 'DHL Express',
    shortName: 'DHL',
    category: 'international',
    brandColor: '#D40511', // DHL Red
    badgeTextColor: '#FFCC00',
    initials: 'DHL',
    searchKeywords: ['dhl', 'dhl express', 'deutsche post'],
    sampleFormat: '10 digits (e.g. 1234567890)',
    popular: true,
  },
  {
    id: 'fedex',
    name: 'FedEx',
    shortName: 'FedEx',
    category: 'international',
    brandColor: '#4D148C', // FedEx Purple
    badgeTextColor: '#FF6600',
    initials: 'FDX',
    searchKeywords: ['fedex', 'federal express'],
    sampleFormat: '12 digits (e.g. 783920183746)',
    popular: true,
  },
  {
    id: 'ups',
    name: 'UPS',
    shortName: 'UPS',
    category: 'international',
    brandColor: '#351C15', // UPS Brown
    badgeTextColor: '#FFB500',
    initials: 'UPS',
    searchKeywords: ['ups', 'united parcel service'],
    sampleFormat: '1Z Tracking (e.g. 1Z9999999999999999)',
  },
  {
    id: 'aramex',
    name: 'Aramex',
    shortName: 'Aramex',
    category: 'international',
    brandColor: '#DC2626', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'ARX',
    searchKeywords: ['aramex', 'middle east aramex'],
    sampleFormat: '9-10 digits (e.g. 392817264)',
  },
  {
    id: 'usps',
    name: 'USPS',
    shortName: 'USPS',
    category: 'international',
    brandColor: '#333366', // USPS Navy
    badgeTextColor: '#FFFFFF',
    initials: 'USPS',
    searchKeywords: ['usps', 'united states postal service'],
    sampleFormat: '20-22 digits or Customs ID',
  },
  {
    id: 'dpd',
    name: 'DPD',
    shortName: 'DPD',
    category: 'international',
    brandColor: '#DC0032', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'DPD',
    searchKeywords: ['dpd', 'dpd group'],
    sampleFormat: '14 digits (e.g. 01234567891011)',
  },
  {
    id: 'gls',
    name: 'GLS',
    shortName: 'GLS',
    category: 'international',
    brandColor: '#002B49', // Blue
    badgeTextColor: '#FFC000',
    initials: 'GLS',
    searchKeywords: ['gls', 'general logistics systems'],
    sampleFormat: '8-12 digits',
  },
  {
    id: 'sf-express',
    name: 'SF Express',
    shortName: 'SF Express',
    category: 'international',
    brandColor: '#D7182A', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'SF',
    searchKeywords: ['sf express', 'shunfeng'],
    sampleFormat: '12 digits (e.g. SF123456789012)',
  },
  {
    id: 'kerry-logistics',
    name: 'Kerry Logistics',
    shortName: 'Kerry',
    category: 'international',
    brandColor: '#C8102E', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'KL',
    searchKeywords: ['kerry logistics', 'kerry'],
    sampleFormat: 'AWB (e.g. KRY128374)',
  },
  {
    id: 'myntra',
    name: 'Myntra',
    shortName: 'Myntra',
    category: 'ecommerce',
    brandColor: '#E11D48', // Myntra Magenta
    badgeTextColor: '#FFFFFF',
    initials: 'MYN',
    searchKeywords: ['myntra', 'fashion delivery'],
    sampleFormat: 'Order ID (e.g. MY1029384756)',
    popular: true,
  },
  {
    id: 'meesho',
    name: 'Meesho',
    shortName: 'Meesho',
    category: 'ecommerce',
    brandColor: '#831843', // Deep Pink
    badgeTextColor: '#FFFFFF',
    initials: 'MSH',
    searchKeywords: ['meesho', 'reseller parcel'],
    sampleFormat: 'Order ID (e.g. MS92837461)',
    popular: true,
  },
  {
    id: 'ajio',
    name: 'AJIO',
    shortName: 'AJIO',
    category: 'ecommerce',
    brandColor: '#1F2937', // Charcoal
    badgeTextColor: '#FFFFFF',
    initials: 'AJIO',
    searchKeywords: ['ajio', 'reliance ajio'],
    sampleFormat: 'Order ID (e.g. FN1234567890)',
  },
  {
    id: 'nykaa',
    name: 'Nykaa',
    shortName: 'Nykaa',
    category: 'ecommerce',
    brandColor: '#EC4899', // Pink
    badgeTextColor: '#FFFFFF',
    initials: 'NYK',
    searchKeywords: ['nykaa', 'beauty parcel'],
    sampleFormat: 'Order ID (e.g. NYK1029384)',
  },
  {
    id: 'tata-cliq',
    name: 'Tata CLiQ',
    shortName: 'Tata CLiQ',
    category: 'ecommerce',
    brandColor: '#BE123C', // Wine
    badgeTextColor: '#FFFFFF',
    initials: 'CLiQ',
    searchKeywords: ['tata cliq', 'tatacliq', 'tata'],
    sampleFormat: 'Order ID (e.g. TC91827364)',
  },
  {
    id: 'jiomart',
    name: 'JioMart',
    shortName: 'JioMart',
    category: 'ecommerce',
    brandColor: '#0284C7', // Jio Blue
    badgeTextColor: '#FFFFFF',
    initials: 'JIO',
    searchKeywords: ['jiomart', 'jio mart', 'reliance'],
    sampleFormat: 'Order ID (e.g. JM10293847)',
  },
  {
    id: 'firstcry',
    name: 'FirstCry',
    shortName: 'FirstCry',
    category: 'ecommerce',
    brandColor: '#F97316', // Orange
    badgeTextColor: '#FFFFFF',
    initials: 'FC',
    searchKeywords: ['firstcry', 'first cry', 'baby parcel'],
    sampleFormat: 'Order ID (e.g. FC83920184)',
  },
  {
    id: 'snapdeal',
    name: 'Snapdeal',
    shortName: 'Snapdeal',
    category: 'ecommerce',
    brandColor: '#E11D48', // Red
    badgeTextColor: '#FFFFFF',
    initials: 'SND',
    searchKeywords: ['snapdeal', 'snap deal'],
    sampleFormat: 'Order ID (e.g. SD91827364)',
  },
  {
    id: 'other',
    name: 'Other Courier Service',
    shortName: 'Other',
    category: 'other',
    brandColor: '#475569', // Slate
    badgeTextColor: '#FFFFFF',
    initials: 'OTH',
    searchKeywords: ['other', 'local courier', 'unlisted', 'not in list'],
    sampleFormat: 'Consignment / Receipt / AWB',
  },
];
