import React from 'react';
import { X, Shield, FileText, AlertTriangle, Mail, Send, CheckCircle2, ExternalLink, Download, Github, Terminal, Copy } from 'lucide-react';
import { GOOGLE_FORM_CONFIG } from '../../config/googleForm';

interface ModalWrapperProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  icon: React.ReactNode;
  children: React.ReactNode;
}

const ModalWrapper: React.FC<ModalWrapperProps> = ({
  isOpen,
  onClose,
  title,
  icon,
  children,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="fixed inset-0" onClick={onClose} />
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[88vh] z-10">
        <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              {icon}
            </div>
            <h3 className="text-lg font-bold text-slate-900">{title}</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition cursor-pointer"
          >
            <X size={20} />
          </button>
        </div>
        <div className="p-5 sm:p-6 overflow-y-auto text-sm text-slate-600 space-y-4 leading-relaxed">
          {children}
        </div>
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs rounded-xl transition cursor-pointer"
          >
            I Understand &amp; Close
          </button>
        </div>
      </div>
    </div>
  );
};

export const PrivacyModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => (
  <ModalWrapper
    isOpen={isOpen}
    onClose={onClose}
    title="Privacy Policy"
    icon={<Shield size={18} />}
  >
    <div className="space-y-4">
      <p className="text-xs text-slate-500">Last updated: October 2026</p>
      
      <div>
        <h4 className="font-bold text-slate-900 mb-1">1. Information We Collect</h4>
        <p>
          When you submit an enquiry through our portal, we may collect the following user-provided details:
        </p>
        <ul className="list-disc pl-5 mt-1 space-y-0.5 text-xs text-slate-600">
          <li>Full Name</li>
          <li>10-Digit Mobile Number</li>
          <li>Courier / Carrier Company selected</li>
          <li>Consignment / Tracking ID / AWB Number</li>
          <li>Shipment destination city or location</li>
        </ul>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">2. Purpose of Collection</h4>
        <p>
          We use this information strictly to facilitate your shipment enquiry, verify shipment statuses through public consignment directories, and provide customer support. We do not sell or rent your personal contact information to third-party telemarketers.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">3. Storage via Google Forms &amp; Google Sheets</h4>
        <p>
          Depending on the deployment settings of this portal, your submitted enquiry data may be stored securely via a connected Google Form or synchronized Google Sheets spreadsheet, accessible only by the verified portal administrator for query tracking.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">4. Data Retention &amp; Security</h4>
        <p>
          We employ industry-standard encryption protocols during transit. Browsing sessions and locally cached enquiries reside in your browser&apos;s localStorage and can be deleted anytime by clearing browser storage or tapping &ldquo;Clear History&rdquo;.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">5. Contact Information</h4>
        <p>
          For questions regarding data processing or to request removal of your submission record, please reach out via our Contact form.
        </p>
      </div>
    </div>
  </ModalWrapper>
);

export const TermsModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => (
  <ModalWrapper
    isOpen={isOpen}
    onClose={onClose}
    title="Terms & Conditions"
    icon={<FileText size={18} />}
  >
    <div className="space-y-4">
      <p className="text-xs text-slate-500">Effective Date: October 2026</p>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">1. Acceptance of Terms</h4>
        <p>
          By using Courier Search, you acknowledge and agree that this service operates solely as an independent shipment query directory and assistance portal.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">2. Non-Affiliation &amp; Independent Operation</h4>
        <p>
          This website is not an official carrier, courier, or postal service. We do not transport physical goods, packages, or courier consignments.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">3. User Responsibilities</h4>
        <p>
          Users must ensure that the Tracking ID and phone numbers submitted belong to their own consignments and are not fraudulent or spam entries.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">4. Limitation of Liability</h4>
        <p>
          We do not guarantee delivery schedules or package safety, as physical logistics are under the sole operational custody of each respective courier company.
        </p>
      </div>
    </div>
  </ModalWrapper>
);

export const DisclaimerModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => (
  <ModalWrapper
    isOpen={isOpen}
    onClose={onClose}
    title="Independent Platform Disclaimer"
    icon={<AlertTriangle size={18} className="text-amber-600" />}
  >
    <div className="space-y-4">
      <div className="p-3.5 bg-amber-50 border border-amber-200 rounded-xl text-amber-900 text-xs font-semibold leading-relaxed">
        &ldquo;This website is an independent shipment enquiry platform and is not affiliated with, endorsed by, or officially connected with the courier, logistics or e-commerce companies listed on this website.&rdquo;
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">Trademarks &amp; Brand Marks</h4>
        <p>
          All company names, logos, registered trademarks, service marks, and trade names (including Amazon, Flipkart, Delhivery, DTDC, Blue Dart, India Post, DHL, FedEx, and others) mentioned on this website belong to their respective owners.
        </p>
        <p className="mt-1">
          Their inclusion in our searchable selector is solely for informational identification and courier routing purposes.
        </p>
      </div>

      <div>
        <h4 className="font-bold text-slate-900 mb-1">Enquiry Resolution Timeline</h4>
        <p>
          Shipment tracking details submitted on this website undergo review. Allow up to 24 hours for enquiry processing. For urgent consignment escalations, please contact your respective carrier directly.
        </p>
      </div>
    </div>
  </ModalWrapper>
);

export const ContactModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const [submitted, setSubmitted] = React.useState(false);

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Contact Support Desk"
      icon={<Mail size={18} />}
    >
      {submitted ? (
        <div className="py-8 text-center">
          <CheckCircle2 size={40} className="text-emerald-500 mx-auto mb-2" />
          <h4 className="text-base font-bold text-slate-900">Message Received</h4>
          <p className="text-xs text-slate-500 mt-1">
            Our helpdesk team will respond to your registered email or phone within 24 hours.
          </p>
          <button
            onClick={() => setSubmitted(false)}
            className="mt-4 px-4 py-1.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-xs font-semibold text-slate-700 cursor-pointer"
          >
            Send Another Query
          </button>
        </div>
      ) : (
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setSubmitted(true);
          }}
          className="space-y-3"
        >
          <p className="text-xs text-slate-500">
            Have an inquiry about our tracking portal or need help with a consignment query?
          </p>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Your Name</label>
            <input
              type="text"
              required
              placeholder="e.g. Rahul Sharma"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Email / Phone</label>
            <input
              type="text"
              required
              placeholder="e.g. rahul@example.com or 9876543210"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Shipment AWB / Subject</label>
            <input
              type="text"
              placeholder="Optional Tracking ID or Question"
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Message</label>
            <textarea
              rows={3}
              required
              placeholder="Describe your issue or shipment question..."
              className="w-full px-3 py-2 border border-slate-300 rounded-xl text-xs focus:ring-2 focus:ring-blue-600 focus:outline-none"
            />
          </div>
          <button
            type="submit"
            className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Send size={14} />
            <span>Submit Support Message</span>
          </button>
        </form>
      )}
    </ModalWrapper>
  );
};

export const GoogleFormGuideModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({
  isOpen,
  onClose,
}) => {
  const [copiedCmd, setCopiedCmd] = React.useState(false);

  const gitCommands = `git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git branch -M main
git push -u origin main`;

  const copyCommands = () => {
    navigator.clipboard.writeText(gitCommands);
    setCopiedCmd(true);
    setTimeout(() => setCopiedCmd(false), 2000);
  };

  return (
    <ModalWrapper
      isOpen={isOpen}
      onClose={onClose}
      title="Download Code & Upload to GitHub"
      icon={<Github size={18} />}
    >
      <div className="space-y-4 text-xs">
        {/* Direct Download ZIP Box */}
        <div className="p-4 bg-emerald-50 border border-emerald-300 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
          <div>
            <span className="font-extrabold text-sm text-emerald-950 block">
              1-Click Download Entire Project
            </span>
            <p className="text-emerald-800 text-[11px] mt-0.5">
              Includes all source files, configurations, components, logos database, and build scripts.
            </p>
          </div>
          <a
            href="/courier-search-india.zip"
            download="courier-search-all-india.zip"
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs rounded-xl shadow-xs transition shrink-0 cursor-pointer"
          >
            <Download size={15} />
            <span>Download All Files (.ZIP)</span>
          </a>
        </div>

        {/* Section 1: Upload to GitHub */}
        <div className="border border-slate-200 rounded-xl p-3.5 space-y-2 bg-slate-50/70">
          <div className="flex items-center gap-1.5 font-bold text-slate-900 text-sm">
            <Github size={16} />
            <span>How to Upload to GitHub</span>
          </div>

          <p className="text-slate-600">
            <strong>Method A (Web Browser - No Git needed):</strong>
          </p>
          <ol className="list-decimal pl-5 space-y-1 text-slate-600 text-[11px]">
            <li>Download the project ZIP above and unzip it on your computer.</li>
            <li>Go to <span className="font-mono text-blue-700">github.com/new</span> and create a new repository.</li>
            <li>Click <strong>&ldquo;uploading an existing file&rdquo;</strong>, drag-and-drop the unzipped project folder, and click <strong>Commit changes</strong>.</li>
          </ol>

          <p className="text-slate-600 pt-1">
            <strong>Method B (Git Terminal):</strong>
          </p>
          <div className="relative">
            <pre className="font-mono bg-slate-900 text-slate-100 p-2.5 rounded-lg text-[11px] overflow-x-auto leading-relaxed">
              {gitCommands}
            </pre>
            <button
              onClick={copyCommands}
              className="absolute right-2 top-2 px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 text-[10px] font-semibold rounded flex items-center gap-1 transition cursor-pointer border border-slate-700"
            >
              {copiedCmd ? <CheckCircle2 size={11} className="text-emerald-400" /> : <Copy size={11} />}
              <span>{copiedCmd ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Section 2: Cloudflare Pages */}
        <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-blue-900 leading-relaxed">
          <strong>Connect to Cloudflare Pages for Free Hosting:</strong>
          <ol className="list-decimal pl-5 mt-1 space-y-0.5 text-[11px] text-blue-950">
            <li>Log in to <span className="font-mono">dash.cloudflare.com</span> &rarr; Workers &amp; Pages &rarr; Create application.</li>
            <li>Select &ldquo;Pages&rdquo; &rarr; &ldquo;Connect to Git&rdquo; and choose your new GitHub repository.</li>
            <li>Framework preset: <strong className="font-mono">Vite</strong> | Build command: <strong className="font-mono">npm run build</strong> | Output: <strong className="font-mono">dist</strong>.</li>
            <li>Click <strong>Deploy</strong> &mdash; your live site will be published with free HTTPS and global CDN.</li>
          </ol>
        </div>

        {/* Section 3: Google Form & Sheets */}
        <div>
          <h4 className="font-bold text-slate-900 text-sm mb-1">
            Google Form &amp; Google Sheets Setup:
          </h4>
          <ol className="list-decimal pl-5 space-y-1 text-slate-600 text-[11px]">
            <li>Create a Google Form with: <em>Full Name, Mobile Number, Courier Company, Tracking ID, Shipment Location</em>.</li>
            <li>In Google Forms Responses, click &ldquo;Link to Sheets&rdquo; to send all queries into Google Sheets.</li>
            <li>Paste your form URL in <span className="font-mono text-blue-700 bg-slate-100 px-1 py-0.2 rounded">src/config/googleForm.ts</span>.</li>
          </ol>
        </div>
      </div>
    </ModalWrapper>
  );
};
