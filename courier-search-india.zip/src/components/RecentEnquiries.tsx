import React, { useState, useEffect } from 'react';
import { ShipmentEnquiryPayload, getLocalEnquiries } from '../config/googleForm';
import { COURIER_DATABASE } from '../data/couriers';
import { CourierLogoBadge } from './CourierLogoBadge';
import { History, Clock, Building2, Barcode, MapPin, CheckCircle2, ChevronRight, Trash2 } from 'lucide-react';

interface RecentEnquiriesProps {
  lastUpdated?: number;
}

export const RecentEnquiries: React.FC<RecentEnquiriesProps> = ({ lastUpdated }) => {
  const [enquiries, setEnquiries] = useState<ShipmentEnquiryPayload[]>([]);
  const [selectedEnquiry, setSelectedEnquiry] = useState<ShipmentEnquiryPayload | null>(null);

  useEffect(() => {
    setEnquiries(getLocalEnquiries());
  }, [lastUpdated]);

  const handleClear = () => {
    if (window.confirm('Clear all your local enquiry history on this browser?')) {
      localStorage.removeItem('courier_search_enquiries');
      setEnquiries([]);
      setSelectedEnquiry(null);
    }
  };

  if (enquiries.length === 0) return null;

  return (
    <section className="py-10 bg-white border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <History size={17} />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold text-slate-900">
                Your Recent Enquiries
              </h3>
              <p className="text-xs text-slate-500">
                Stored locally on your device for quick reference
              </p>
            </div>
          </div>

          <button
            onClick={handleClear}
            className="text-xs text-slate-400 hover:text-rose-600 flex items-center gap-1 transition cursor-pointer"
            title="Clear history"
          >
            <Trash2 size={13} />
            <span className="hidden sm:inline">Clear History</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {enquiries.slice(0, 6).map((item) => {
            const courier = COURIER_DATABASE.find((c) => c.id === item.courierId) || {
              id: 'other',
              name: item.courierCompany,
              brandColor: '#2563eb',
              badgeTextColor: '#ffffff',
              initials: item.courierCompany.slice(0, 2),
              category: 'other' as const,
              searchKeywords: [],
              sampleFormat: '',
            };

            return (
              <div
                key={item.referenceId}
                className="p-3.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-white hover:border-blue-400 hover:shadow-xs transition-all text-xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-2 pb-2 border-b border-slate-200/60">
                    <div className="flex items-center gap-2 min-w-0">
                      <CourierLogoBadge courier={courier} size="sm" />
                      <span className="font-bold text-slate-800 truncate">
                        {item.courierCompany}
                      </span>
                    </div>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800">
                      <CheckCircle2 size={10} />
                      {item.status}
                    </span>
                  </div>

                  <div className="space-y-1 text-slate-600">
                    <div className="flex justify-between">
                      <span className="text-slate-400">Ref:</span>
                      <span className="font-mono font-bold text-blue-700">{item.referenceId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">AWB/ID:</span>
                      <span className="font-mono text-slate-800">{item.trackingId}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-400">Location:</span>
                      <span className="text-slate-700 truncate max-w-[150px]">{item.shipmentLocation}</span>
                    </div>
                  </div>
                </div>

                <div className="mt-2.5 pt-2 border-t border-slate-200/50 flex items-center justify-between text-[11px] text-slate-400">
                  <span className="flex items-center gap-1">
                    <Clock size={12} />
                    {item.submittedAt}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
