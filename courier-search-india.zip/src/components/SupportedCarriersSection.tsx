import React, { useState } from 'react';
import { COURIER_DATABASE, CourierCompany } from '../data/couriers';
import { CourierLogoBadge } from './CourierLogoBadge';
import { Building2, Search, ArrowRight, CheckCircle2 } from 'lucide-react';

interface SupportedCarriersSectionProps {
  onSelectCourier: (courier: CourierCompany) => void;
}

export const SupportedCarriersSection: React.FC<SupportedCarriersSectionProps> = ({
  onSelectCourier,
}) => {
  const [filter, setFilter] = useState<'all' | 'popular' | 'ecommerce'>('popular');
  const [query, setQuery] = useState('');

  const displayList = COURIER_DATABASE.filter((c) => {
    if (filter === 'popular' && !c.popular) return false;
    if (filter === 'ecommerce' && c.category !== 'ecommerce') return false;
    if (query) {
      return (
        c.name.toLowerCase().includes(query.toLowerCase()) ||
        c.searchKeywords.some((k) => k.toLowerCase().includes(query.toLowerCase()))
      );
    }
    return true;
  });

  const handleSelect = (courier: CourierCompany) => {
    onSelectCourier(courier);
    const cardEl = document.getElementById('track-card');
    if (cardEl) {
      cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <section className="py-14 sm:py-16 bg-slate-50 border-t border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-8">
          <div>
            <div className="inline-flex items-center gap-1 text-xs font-bold text-blue-700 uppercase tracking-wider mb-2">
              <Building2 size={14} /> Carrier Directory
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Supported Logistics &amp; Delivery Partners
            </h2>
            <p className="text-slate-500 text-xs sm:text-sm mt-1">
              Select any carrier below to quickly pre-fill your enquiry form above.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilter('popular')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                filter === 'popular'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Popular Couriers
            </button>
            <button
              onClick={() => setFilter('ecommerce')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                filter === 'ecommerce'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              E-Commerce Carriers
            </button>
            <button
              onClick={() => setFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition cursor-pointer ${
                filter === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              All ({COURIER_DATABASE.length})
            </button>
          </div>
        </div>

        {/* Compact Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-2.5 sm:gap-3">
          {displayList.slice(0, 18).map((courier) => (
            <button
              key={courier.id}
              onClick={() => handleSelect(courier)}
              className="flex items-center gap-2.5 p-2.5 bg-white border border-slate-200/90 rounded-xl hover:border-blue-500 hover:shadow-sm transition-all group text-left cursor-pointer"
            >
              <CourierLogoBadge courier={courier} size="sm" />
              <div className="min-w-0 flex-1">
                <span className="text-xs font-bold text-slate-800 group-hover:text-blue-600 truncate block">
                  {courier.name}
                </span>
                <span className="text-[10px] text-slate-400 capitalize truncate block">
                  {courier.category}
                </span>
              </div>
            </button>
          ))}
        </div>

        {displayList.length > 18 && (
          <div className="text-center mt-6">
            <button
              onClick={() => {
                const cardEl = document.getElementById('track-card');
                if (cardEl) {
                  cardEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }
              }}
              className="inline-flex items-center gap-1.5 text-xs font-bold text-blue-600 hover:text-blue-800 bg-blue-50 px-4 py-2 rounded-xl border border-blue-200 transition cursor-pointer"
            >
              <span>Explore all {COURIER_DATABASE.length} companies in the main search selector</span>
              <ArrowRight size={14} />
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
