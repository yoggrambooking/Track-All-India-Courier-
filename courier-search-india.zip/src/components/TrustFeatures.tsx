import React from 'react';
import { Layers, FileCheck, Barcode, Smartphone } from 'lucide-react';

export const TrustFeatures: React.FC = () => {
  const features = [
    {
      title: 'Multiple Courier Options',
      desc: 'Enquire for parcels across major domestic carriers, postal networks, hyper-local couriers, and international freight operators.',
      icon: Layers,
      color: 'text-blue-600 bg-blue-50 border-blue-200',
    },
    {
      title: 'Simple Shipment Enquiry',
      desc: 'Straightforward submission form with zero unnecessary popups, hidden fees, or convoluted portal registrations.',
      icon: FileCheck,
      color: 'text-indigo-600 bg-indigo-50 border-indigo-200',
    },
    {
      title: 'Easy Tracking ID Submission',
      desc: 'Supports AWB, Consignment number, Order ID, Docket number, or LR formats across all active Indian logistics partners.',
      icon: Barcode,
      color: 'text-emerald-600 bg-emerald-50 border-emerald-200',
    },
    {
      title: 'Mobile Friendly',
      desc: 'Optimized responsive interface crafted for one-hand smartphone navigation, fast loading, and minimal cellular data usage.',
      icon: Smartphone,
      color: 'text-amber-600 bg-amber-50 border-amber-200',
    },
  ];

  return (
    <section className="py-16 sm:py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-14">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-100 text-slate-800 text-xs font-bold uppercase tracking-wider mb-3">
            Core Features
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
            Designed for Fast &amp; Reliable Parcel Enquiries
          </h2>
          <p className="mt-3 text-slate-600 text-sm sm:text-base">
            An independent, clean directory and enquiry tool built for everyday senders and online shoppers.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.title}
                className="p-6 rounded-2xl border border-slate-200 bg-white hover:border-blue-300 hover:shadow-lg transition-all group"
              >
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-5 border ${item.color} group-hover:scale-105 transition-transform`}
                >
                  <Icon size={24} />
                </div>
                <div className="flex items-center gap-1.5 mb-2">
                  <span className="text-emerald-600 font-bold text-sm">✓</span>
                  <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-600 transition">
                    {item.title}
                  </h3>
                </div>
                <p className="text-xs sm:text-sm text-slate-500 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
