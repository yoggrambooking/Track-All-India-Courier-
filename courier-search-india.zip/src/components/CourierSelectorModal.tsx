import React, { useState, useMemo, useEffect, useRef } from 'react';
import { COURIER_DATABASE, CourierCompany } from '../data/couriers';
import { CourierLogoBadge } from './CourierLogoBadge';
import { Search, X, Check, Sparkles, Building2, Flame } from 'lucide-react';

interface CourierSelectorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (courier: CourierCompany) => void;
  selectedCourier: CourierCompany | null;
}

export const CourierSelectorModal: React.FC<CourierSelectorModalProps> = ({
  isOpen,
  onClose,
  onSelect,
  selectedCourier,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState<'all' | 'popular' | 'ecommerce' | 'express' | 'cargo' | 'international'>('all');
  const searchInputRef = useRef<HTMLInputElement>(null);

  // Focus search input when modal opens
  useEffect(() => {
    if (isOpen) {
      setTimeout(() => {
        searchInputRef.current?.focus();
      }, 100);
    } else {
      setSearchQuery('');
      setActiveTab('all');
    }
  }, [isOpen]);

  // Handle ESC key to close
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  // Filtered and sorted couriers
  const filteredCouriers = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();

    return COURIER_DATABASE.filter((courier) => {
      // Tab filter
      if (activeTab === 'popular' && !courier.popular) return false;
      if (activeTab === 'ecommerce' && courier.category !== 'ecommerce') return false;
      if (activeTab === 'express' && courier.category !== 'express' && courier.category !== 'popular') return false;
      if (activeTab === 'cargo' && courier.category !== 'cargo') return false;
      if (activeTab === 'international' && courier.category !== 'international') return false;

      // Query filter
      if (!query) return true;

      const nameMatch = courier.name.toLowerCase().includes(query);
      const shortNameMatch = courier.shortName?.toLowerCase().includes(query);
      const keywordMatch = courier.searchKeywords.some((k) => k.toLowerCase().includes(query));

      return nameMatch || shortNameMatch || keywordMatch;
    });
  }, [searchQuery, activeTab]);

  const popularCouriers = useMemo(() => {
    return COURIER_DATABASE.filter((c) => c.popular);
  }, []);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      {/* Backdrop click to dismiss */}
      <div className="fixed inset-0" onClick={onClose} />

      {/* Modal Container */}
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh] z-10 transition-all">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-center justify-between gap-3 mb-3">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center font-bold">
                <Building2 size={18} />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900 leading-snug">
                  Choose Courier Company
                </h3>
                <p className="text-xs text-slate-500">
                  Select your carrier from 40+ logistics and e-commerce partners
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors cursor-pointer"
              aria-label="Close dialog"
            >
              <X size={20} />
            </button>
          </div>

          {/* Search Input */}
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size={18} />
            <input
              ref={searchInputRef}
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search company (e.g. Amazon, Blue Dart, Delhivery, Ekart...)"
              className="w-full pl-10 pr-9 py-2.5 bg-white border border-slate-300 rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-600 focus:border-transparent transition shadow-xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                aria-label="Clear search"
              >
                <X size={16} />
              </button>
            )}
          </div>

          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pt-3 pb-0.5 scrollbar-none text-xs">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                activeTab === 'all'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              All Couriers ({COURIER_DATABASE.length})
            </button>
            <button
              onClick={() => setActiveTab('popular')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition flex items-center gap-1 cursor-pointer ${
                activeTab === 'popular'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              <Flame size={13} className={activeTab === 'popular' ? 'text-amber-300' : 'text-amber-500'} />
              Most Popular
            </button>
            <button
              onClick={() => setActiveTab('ecommerce')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                activeTab === 'ecommerce'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              E-Commerce
            </button>
            <button
              onClick={() => setActiveTab('express')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                activeTab === 'express'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Express & Air
            </button>
            <button
              onClick={() => setActiveTab('cargo')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                activeTab === 'cargo'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              Heavy Cargo
            </button>
            <button
              onClick={() => setActiveTab('international')}
              className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition cursor-pointer ${
                activeTab === 'international'
                  ? 'bg-blue-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              International
            </button>
          </div>
        </div>

        {/* Courier List */}
        <div className="overflow-y-auto p-3 sm:p-4 divide-y divide-slate-100 max-h-[55vh]">
          {/* Quick selection chips for top popular when searching is empty and on 'all' tab */}
          {!searchQuery && activeTab === 'all' && (
            <div className="pb-3 mb-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-500 uppercase tracking-wider mb-2">
                <Sparkles size={13} className="text-amber-500" />
                Frequently Tracked in India
              </div>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {popularCouriers.slice(0, 6).map((c) => {
                  const isSelected = selectedCourier?.id === c.id;
                  return (
                    <button
                      key={c.id}
                      onClick={() => {
                        onSelect(c);
                        onClose();
                      }}
                      className={`flex items-center gap-2 p-2 rounded-xl text-left border transition cursor-pointer ${
                        isSelected
                          ? 'border-blue-500 bg-blue-50/70 text-blue-900 ring-1 ring-blue-500'
                          : 'border-slate-200 hover:border-blue-300 hover:bg-slate-50'
                      }`}
                    >
                      <CourierLogoBadge courier={c} size="sm" />
                      <div className="min-w-0 flex-1">
                        <div className="text-xs font-semibold text-slate-800 truncate">
                          {c.name}
                        </div>
                      </div>
                      {isSelected && <Check size={14} className="text-blue-600 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {filteredCouriers.length === 0 ? (
            <div className="text-center py-10 px-4">
              <Building2 className="mx-auto text-slate-300 mb-2" size={36} />
              <p className="text-sm font-semibold text-slate-700">No matching courier company found</p>
              <p className="text-xs text-slate-500 mt-1">
                Try typing keywords like &ldquo;Amazon&rdquo;, &ldquo;Delhivery&rdquo;, or choose &ldquo;Other Courier Service&rdquo;.
              </p>
              <button
                onClick={() => {
                  const other = COURIER_DATABASE.find((c) => c.id === 'other');
                  if (other) {
                    onSelect(other);
                    onClose();
                  }
                }}
                className="mt-4 inline-flex items-center gap-1.5 px-3 py-1.5 bg-blue-50 text-blue-700 text-xs font-semibold rounded-lg hover:bg-blue-100 transition cursor-pointer"
              >
                Select &ldquo;Other Courier Service&rdquo;
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 pt-1">
              {filteredCouriers.map((courier) => {
                const isSelected = selectedCourier?.id === courier.id;
                return (
                  <button
                    key={courier.id}
                    onClick={() => {
                      onSelect(courier);
                      onClose();
                    }}
                    className={`flex items-center justify-between p-2.5 rounded-xl border text-left transition group cursor-pointer ${
                      isSelected
                        ? 'border-blue-600 bg-blue-50/80 ring-1 ring-blue-600 text-blue-950'
                        : 'border-slate-100 hover:border-blue-200 hover:bg-slate-50/80 text-slate-800'
                    }`}
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <CourierLogoBadge courier={courier} size="md" />
                      <div className="min-w-0">
                        <div className="text-sm font-bold text-slate-900 group-hover:text-blue-600 truncate flex items-center gap-1.5">
                          {courier.name}
                          {courier.popular && (
                            <span className="text-[10px] font-semibold uppercase px-1.5 py-0.2 bg-amber-100 text-amber-800 rounded">
                              Top
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 truncate">
                          ID: {courier.sampleFormat}
                        </div>
                      </div>
                    </div>

                    <div className="shrink-0 pl-2">
                      {isSelected ? (
                        <div className="w-6 h-6 rounded-full bg-blue-600 text-white flex items-center justify-center shadow-xs">
                          <Check size={14} strokeWidth={3} />
                        </div>
                      ) : (
                        <span className="text-xs text-slate-400 group-hover:text-blue-600 font-medium">
                          Select
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <span>{filteredCouriers.length} companies available</span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium rounded-lg transition cursor-pointer"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
