import React, { useState } from 'react';
import { Truck, Menu, X, Search, ShieldCheck, HelpCircle, PhoneCall, Code, Download } from 'lucide-react';

interface HeaderProps {
  onOpenContact: () => void;
  onOpenGuide: () => void;
  onTrackClick: () => void;
  onHowItWorksClick: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenContact,
  onOpenGuide,
  onTrackClick,
  onHowItWorksClick,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-slate-900/90 backdrop-blur-md border-b border-slate-800 text-white transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <a
              href="#"
              className="flex items-center gap-2.5 group focus:outline-none"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-500 flex items-center justify-center text-white shadow-md shadow-blue-500/20 group-hover:scale-105 transition-transform">
                <Truck size={22} />
              </div>
              <div>
                <span className="text-lg sm:text-xl font-black tracking-tight text-white flex items-center gap-1.5">
                  Courier Search
                  <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded bg-blue-500/20 text-blue-400 border border-blue-400/30 uppercase tracking-wider">
                    India
                  </span>
                </span>
                <span className="text-[10px] text-slate-400 block -mt-0.5 hidden sm:block">
                  Shipment Tracking &amp; Enquiry Portal
                </span>
              </div>
            </a>
          </div>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 text-sm font-semibold text-slate-300">
            <a
              href="#"
              onClick={(e) => {
                e.preventDefault();
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-3.5 py-2 rounded-lg hover:text-white hover:bg-white/5 transition"
            >
              Home
            </a>
            <button
              onClick={onTrackClick}
              className="px-3.5 py-2 rounded-lg hover:text-white hover:bg-white/5 transition cursor-pointer"
            >
              Track Shipment
            </button>
            <button
              onClick={onHowItWorksClick}
              className="px-3.5 py-2 rounded-lg hover:text-white hover:bg-white/5 transition cursor-pointer"
            >
              How It Works
            </button>
            <button
              onClick={onOpenContact}
              className="px-3.5 py-2 rounded-lg hover:text-white hover:bg-white/5 transition cursor-pointer"
            >
              Contact
            </button>
          </nav>

          {/* CTA & Deployment Info button */}
          <div className="hidden sm:flex items-center gap-2">
            <a
              href="/courier-search-india.zip"
              download="courier-search-all-india.zip"
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-emerald-300 hover:text-emerald-200 bg-emerald-950/60 hover:bg-emerald-900/60 border border-emerald-500/30 transition flex items-center gap-1.5 shadow-2xs"
              title="Download full project source code as ZIP"
            >
              <Download size={13} />
              <span>Download ZIP</span>
            </a>

            <button
              onClick={onOpenGuide}
              className="px-3 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white bg-white/5 hover:bg-white/10 border border-white/10 transition flex items-center gap-1.5 cursor-pointer"
              title="GitHub & Cloudflare Pages upload guide"
            >
              <Code size={13} />
              <span>GitHub / Cloudflare</span>
            </button>

            <button
              onClick={onTrackClick}
              className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-500 text-white text-xs font-extrabold shadow-sm shadow-blue-500/20 transition flex items-center gap-1.5 cursor-pointer active:scale-95"
            >
              <Search size={14} />
              <span>Track Now</span>
            </button>
          </div>

          {/* Mobile Hamburger Button */}
          <div className="flex md:hidden items-center gap-2">
            <a
              href="/courier-search-india.zip"
              download="courier-search-all-india.zip"
              className="p-2 rounded-lg bg-emerald-900/60 border border-emerald-500/30 text-emerald-300 text-xs font-bold flex items-center gap-1"
              title="Download ZIP"
            >
              <Download size={16} />
              <span className="text-[11px]">ZIP</span>
            </a>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-lg bg-slate-800 text-slate-300 hover:text-white hover:bg-slate-700 transition cursor-pointer"
              aria-label="Toggle navigation"
            >
              {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-slate-900 border-b border-slate-800 px-4 pt-2 pb-5 space-y-2 animate-in slide-in-from-top-2">
          <a
            href="#"
            onClick={(e) => {
              e.preventDefault();
              window.scrollTo({ top: 0, behavior: 'smooth' });
              setMobileMenuOpen(false);
            }}
            className="block px-3 py-2.5 rounded-lg text-sm font-semibold text-slate-200 hover:bg-slate-800"
          >
            Home
          </a>
          <button
            onClick={() => {
              onTrackClick();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            Track Shipment
          </button>
          <button
            onClick={() => {
              onHowItWorksClick();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            How It Works
          </button>
          <button
            onClick={() => {
              onOpenContact();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-slate-200 hover:bg-slate-800 cursor-pointer"
          >
            Contact
          </button>
          <a
            href="/courier-search-india.zip"
            download="courier-search-all-india.zip"
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-emerald-400 hover:bg-slate-800 flex items-center gap-2"
          >
            <Download size={15} />
            <span>Download All Code (ZIP)</span>
          </a>
          <button
            onClick={() => {
              onOpenGuide();
              setMobileMenuOpen(false);
            }}
            className="w-full text-left px-3 py-2.5 rounded-lg text-sm font-semibold text-blue-400 hover:bg-slate-800 cursor-pointer flex items-center gap-2"
          >
            <Code size={15} />
            <span>Direct Upload to GitHub Instructions</span>
          </button>
          <div className="pt-2">
            <button
              onClick={() => {
                onTrackClick();
                setMobileMenuOpen(false);
              }}
              className="w-full py-2.5 bg-blue-600 text-white rounded-xl text-center text-sm font-bold shadow-md cursor-pointer"
            >
              Search Your Shipment Now
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
