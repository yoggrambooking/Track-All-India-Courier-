import React from 'react';
import { Building2, PhoneCall, Barcode, Send, Headset } from 'lucide-react';

export const HowItWorks: React.FC = () => {
  const steps = [
    {
      step: '1',
      title: 'Choose Courier',
      desc: 'Pick your carrier from our database of over 40+ logistics and e-commerce companies.',
      icon: Building2,
      accent: 'bg-blue-100 text-blue-700',
    },
    {
      step: '2',
      title: 'Phone Number',
      desc: 'Provide your 10-digit mobile number so enquiry logs can be matched with your parcel.',
      icon: PhoneCall,
      accent: 'bg-indigo-100 text-indigo-700',
    },
    {
      step: '3',
      title: 'Enter Tracking Details',
      desc: 'Fill in your Consignment / AWB / Order Tracking ID and your destination city or state.',
      icon: Barcode,
      accent: 'bg-amber-100 text-amber-800',
    },
    {
      step: '4',
      title: 'Submit Shipment Enquiry',
      desc: 'Click "Search Courier" to register your shipment details into our tracking directory.',
      icon: Send,
      accent: 'bg-purple-100 text-purple-700',
    },
    {
      step: '5',
      title: 'Receive Assistance / Update',
      desc: 'Allow up to 24 hours for review against carrier dispatch networks to help resolve parcel queries.',
      icon: Headset,
      accent: 'bg-emerald-100 text-emerald-700',
    },
  ];

  return (
    <section id="how-it-works" className="py-16 sm:py-20 bg-slate-50 border-t border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-xs font-bold uppercase tracking-wider mb-3">
            Streamlined Process
          </div>
          <h2 className="text-2xl sm:text-3xl md:text-4xl font-black text-slate-900 tracking-tight">
            How It Works
          </h2>
          <p className="mt-3 text-slate-600 text-sm sm:text-base">
            Submit your consignment enquiry in 5 simple steps without needing multiple carrier logins.
          </p>
        </div>

        {/* 5-step grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-6 relative">
          {steps.map((item, idx) => {
            const Icon = item.icon;
            return (
              <div
                key={item.step}
                className="relative bg-white p-5 sm:p-6 rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all group flex flex-col justify-between"
              >
                <div>
                  {/* Step badge & icon */}
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-xs font-black text-slate-400 font-mono">
                      STEP 0{item.step}
                    </span>
                    <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold shadow-2xs ${item.accent}`}>
                      <Icon size={20} />
                    </div>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 mb-2 group-hover:text-blue-600 transition">
                    {item.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed">
                    {item.desc}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center text-[11px] font-semibold text-slate-400">
                  <span>Phase {item.step} of 5</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
