import React from 'react';
import { TrackingCard } from './TrackingCard';
import { ShipmentEnquiryPayload } from '../config/googleForm';
import {
  Truck,
  Package,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  Clock,
  Compass,
  ArrowDown,
  Sparkles,
} from 'lucide-react';

interface HeroSectionProps {
  onSuccess: (data: ShipmentEnquiryPayload) => void;
  onSelectCourierPrompt: () => void;
  preselectedCourierId?: string | null;
}

export const HeroSection: React.FC<HeroSectionProps> = ({
  onSuccess,
  preselectedCourierId,
}) => {
  const scrollToCard = () => {
    const el = document.getElementById('track-card');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  return (
    <section className="relative overflow-hidden bg-gradient-to-b from-slate-900 via-blue-950 to-slate-900 text-white pt-12 pb-20 sm:pt-16 sm:pb-28">
      {/* Background Logistics Grid & Ambient Glow */}
      <div className="absolute inset-0 opacity-15 pointer-events-none">
        <svg className="w-full h-full" xmlns="http://www.w3.org/2000/svg">
          <defs>
            <pattern id="grid-pattern" width="48" height="48" patternUnits="userSpaceOnUse">
              <path d="M 48 0 L 0 0 0 48" fill="none" stroke="#60a5fa" strokeWidth="0.8" />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid-pattern)" />
        </svg>
      </div>

      {/* Radial soft lights */}
      <div className="absolute top-10 left-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-10 right-10 w-96 h-96 bg-indigo-500/20 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-8 items-center">
          {/* Left Column: Hero Text & Visual Logistics Highlights */}
          <div className="lg:col-span-6 text-center lg:text-left space-y-6">
            {/* Top Pill */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-blue-500/15 border border-blue-400/30 text-blue-300 text-xs sm:text-sm font-medium backdrop-blur-md">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Independent All-India Consignment Portal</span>
            </div>

            {/* Main Heading & Subheading */}
            <div>
              <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white leading-tight sm:leading-none">
                Track Your <span className="bg-gradient-to-r from-blue-400 via-sky-300 to-indigo-300 bg-clip-text text-transparent">Courier</span>
              </h1>
              <p className="mt-4 text-base sm:text-lg text-slate-300 max-w-xl mx-auto lg:mx-0 font-normal leading-relaxed">
                Select your courier company, enter your tracking details and submit your shipment enquiry.
              </p>
            </div>

            {/* Prominent CTA requested in spec */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-3.5 pt-1">
              <button
                onClick={scrollToCard}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-blue-600/30 transition-all cursor-pointer active:scale-95"
              >
                <Truck size={20} />
                <span>Track All India Courier Service</span>
                <ArrowDown size={17} className="animate-bounce" />
              </button>
              <div className="text-xs text-slate-400 flex items-center gap-1.5">
                <CheckCircle2 size={15} className="text-emerald-400 shrink-0" />
                <span>Support for 40+ Domestic &amp; Global Couriers</span>
              </div>
            </div>

            {/* Logistics Feature Cards / Visual Badges */}
            <div className="grid grid-cols-3 gap-3 pt-4 max-w-md mx-auto lg:mx-0">
              <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center sm:text-left backdrop-blur-xs">
                <div className="w-8 h-8 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mx-auto sm:mx-0 mb-2">
                  <Package size={17} />
                </div>
                <div className="text-base sm:text-lg font-black text-white">40+</div>
                <div className="text-[11px] text-slate-400 leading-tight">Couriers Covered</div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center sm:text-left backdrop-blur-xs">
                <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 flex items-center justify-center mx-auto sm:mx-0 mb-2">
                  <MapPin size={17} />
                </div>
                <div className="text-base sm:text-lg font-black text-white">All India</div>
                <div className="text-[11px] text-slate-400 leading-tight">Pin Codes Served</div>
              </div>

              <div className="bg-white/5 border border-white/10 rounded-xl p-3 text-center sm:text-left backdrop-blur-xs">
                <div className="w-8 h-8 rounded-lg bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto sm:mx-0 mb-2">
                  <Clock size={17} />
                </div>
                <div className="text-base sm:text-lg font-black text-white">Fast Review</div>
                <div className="text-[11px] text-slate-400 leading-tight">Within 24 Hours</div>
              </div>
            </div>

            {/* Visual Logistics Van & Map Graphic banner */}
            <div className="p-3.5 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center gap-3.5 backdrop-blur-sm max-w-lg mx-auto lg:mx-0 text-left">
              <div className="w-10 h-10 rounded-lg bg-blue-600/30 text-blue-300 flex items-center justify-center shrink-0">
                <Truck size={22} />
              </div>
              <div className="text-xs text-slate-300">
                <span className="font-semibold text-white block">Centralized Enquiry Management</span>
                Submit consignments from Delhivery, Blue Dart, DTDC, India Post, Amazon, Flipkart, Speed Post and more in one place.
              </div>
            </div>
          </div>

          {/* Right Column: MAIN TRACKING CARD */}
          <div className="lg:col-span-6">
            <TrackingCard
              onSuccess={onSuccess}
              preselectedCourierId={preselectedCourierId}
            />
          </div>
        </div>
      </div>
    </section>
  );
};
