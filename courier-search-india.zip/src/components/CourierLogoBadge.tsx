import React from 'react';
import { CourierCompany } from '../data/couriers';
import { Package, Truck, Plane, Globe, ShoppingBag, ShieldCheck } from 'lucide-react';

interface CourierLogoBadgeProps {
  courier: CourierCompany;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
  showName?: boolean;
}

export const CourierLogoBadge: React.FC<CourierLogoBadgeProps> = ({
  courier,
  size = 'md',
  className = '',
  showName = false,
}) => {
  const sizeClasses = {
    sm: 'w-7 h-7 text-[10px]',
    md: 'w-9 h-9 text-xs',
    lg: 'w-12 h-12 text-sm',
  };

  const iconSizes = {
    sm: 14,
    md: 18,
    lg: 22,
  };

  // Render distinctive visual branding elements based on carrier characteristics
  const renderBrandedContent = () => {
    switch (courier.id) {
      case 'delhivery':
        return (
          <div className="flex flex-col items-center justify-center font-black tracking-tighter">
            <span className="text-[11px] leading-none font-sans">DLV</span>
            <div className="w-4 h-0.5 bg-red-400 mt-0.5 rounded-full" />
          </div>
        );
      case 'bluedart':
        return (
          <div className="flex items-center justify-center font-black tracking-tight text-yellow-300">
            <span>BD</span>
          </div>
        );
      case 'dtdc':
        return (
          <div className="flex flex-col items-center justify-center font-bold text-[10px]">
            <span className="tracking-tight">DTDC</span>
          </div>
        );
      case 'indiapost':
      case 'speedpost':
        return (
          <div className="flex flex-col items-center justify-center">
            <span className="font-extrabold text-[11px] text-yellow-200">डाक</span>
          </div>
        );
      case 'amazon':
      case 'amazon-shipping':
        return (
          <div className="flex flex-col items-center justify-center text-slate-900">
            <span className="font-black text-xs">a</span>
            <div className="w-3.5 h-0.5 bg-orange-500 rounded-full" />
          </div>
        );
      case 'flipkart':
      case 'ekart':
        return (
          <div className="flex items-center justify-center font-black text-white">
            <span className="italic">fk</span>
          </div>
        );
      case 'dhl':
        return (
          <div className="flex items-center justify-center font-black tracking-tighter text-amber-950">
            <span>DHL</span>
          </div>
        );
      case 'fedex':
        return (
          <div className="flex items-center justify-center font-black text-[10px] tracking-tight">
            <span className="text-purple-100">Fed</span>
            <span className="text-orange-300">Ex</span>
          </div>
        );
      case 'ups':
        return (
          <div className="flex items-center justify-center font-black text-[11px] text-amber-400">
            <span>UPS</span>
          </div>
        );
      case 'shiprocket':
      case 'shiprocket-x':
        return (
          <div className="flex items-center justify-center">
            <Package size={iconSizes[size]} className="text-purple-200" />
          </div>
        );
      case 'shadowfax':
        return (
          <div className="flex items-center justify-center">
            <Truck size={iconSizes[size]} className="text-emerald-100" />
          </div>
        );
      case 'ecom-express':
        return (
          <div className="flex items-center justify-center font-black text-[10px] text-sky-200">
            <span>ECOM</span>
          </div>
        );
      case 'xpressbees':
        return (
          <div className="flex items-center justify-center font-bold text-[10px] text-slate-900">
            <span>XB</span>
          </div>
        );
      default:
        // Category based icon or initials
        if (courier.category === 'international') {
          return <Globe size={iconSizes[size]} className="text-white/90" />;
        }
        if (courier.category === 'ecommerce') {
          return <ShoppingBag size={iconSizes[size]} className="text-white/90" />;
        }
        return (
          <span className="font-bold tracking-tight text-white uppercase">
            {courier.initials.slice(0, 4)}
          </span>
        );
    }
  };

  return (
    <div className={`inline-flex items-center gap-2.5 ${className}`}>
      <div
        className={`${sizeClasses[size]} rounded-xl shadow-xs flex items-center justify-center font-semibold shrink-0 transition-transform select-none`}
        style={{
          backgroundColor: courier.brandColor,
          color: courier.badgeTextColor,
        }}
        title={courier.name}
      >
        {renderBrandedContent()}
      </div>
      {showName && (
        <span className="font-medium text-slate-900 truncate">
          {courier.name}
        </span>
      )}
    </div>
  );
};
