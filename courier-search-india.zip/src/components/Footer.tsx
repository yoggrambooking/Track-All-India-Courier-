import React from 'react';
import { Truck, ShieldCheck, AlertTriangle, ExternalLink, Heart } from 'lucide-react';

interface FooterProps {
  onOpenPrivacy: () => void;
  onOpenTerms: () => void;
  onOpenDisclaimer: () => void;
  onOpenContact: () => void;
  onOpenGuide: () => void;
  onTrackClick: () => void;
  onHowItWorksClick: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onOpenPrivacy,
  onOpenTerms,
  onOpenDisclaimer,
  onOpenContact,
  onOpenGuide,
  onTrackClick,
  onHowItWorksClick,
}) => {
  return (
    <footer className="bg-slate-950 text-slate-400 border-t border-slate-800 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16">
        {/* Mandatory Independent Platform Disclaimer Box */}
        <div className="mb-10 p-4 sm:p-5 rounded-2xl bg-slate-900 border border-slate-800 text-slate-300">
          <div className="flex items-start gap-3">
            <AlertTriangle className="text-amber-400 shrink-0 mt-0.5" size={20} />
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider">
                Independent Platform Disclaimer
              </h4>
              <p className="text-xs sm:text-sm text-slate-300 font-medium leading-relaxed">
                &ldquo;This website is an independent shipment enquiry platform and is not affiliated with, endorsed by, or officially connected with the courier, logistics or e-commerce companies listed on this website.&rdquo;
              </p>
              <p className="text-[11px] text-slate-400 leading-normal pt-1">
                All courier company names, brand marks, and trademarks belong to their respective corporate entities.
              </p>
            </div>
          </div>
        </div>

        {/* 4-column footer layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-10">
          {/* Brand Info */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold">
                <Truck size={18} />
              </div>
              <span className="text-base font-black text-white">Courier Search</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              Consolidated shipment enquiry &amp; consignment directory for parcels sent across all 28 states and union territories in India.
            </p>
            <div className="pt-1">
              <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-900 border border-slate-800 text-[11px] text-slate-300">
                <ShieldCheck size={13} className="text-emerald-400" />
                100% Free Public Directory
              </span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Navigation</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a
                  href="#"
                  onClick={(e) => {
                    e.preventDefault();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="hover:text-white transition"
                >
                  Home
                </a>
              </li>
              <li>
                <button onClick={onTrackClick} className="hover:text-white transition cursor-pointer text-left">
                  Track Consignment
                </button>
              </li>
              <li>
                <button onClick={onHowItWorksClick} className="hover:text-white transition cursor-pointer text-left">
                  How It Works
                </button>
              </li>
              <li>
                <button onClick={onOpenContact} className="hover:text-white transition cursor-pointer text-left">
                  Contact Support Desk
                </button>
              </li>
            </ul>
          </div>

          {/* Legal & Compliance */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Legal &amp; Policy</h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={onOpenDisclaimer} className="hover:text-white transition cursor-pointer text-left text-amber-400/90 hover:text-amber-300">
                  Disclaimer Notice
                </button>
              </li>
              <li>
                <button onClick={onOpenPrivacy} className="hover:text-white transition cursor-pointer text-left">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={onOpenTerms} className="hover:text-white transition cursor-pointer text-left">
                  Terms &amp; Conditions
                </button>
              </li>
              <li>
                <button onClick={onOpenGuide} className="hover:text-white transition cursor-pointer text-left text-blue-400 hover:text-blue-300 flex items-center gap-1">
                  <span>Google Form &amp; Cloudflare</span>
                  <ExternalLink size={11} />
                </button>
              </li>
            </ul>
          </div>

          {/* Service Notice */}
          <div className="space-y-2.5">
            <h4 className="text-xs font-bold text-white uppercase tracking-wider">Enquiry Service</h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              We process shipment tracking inquiries and provide query resolution assistance within 24 business hours.
            </p>
            <p className="text-[11px] text-slate-500">
              Coverage: Delhivery, Blue Dart, DTDC, India Post, Amazon, Flipkart, Ekart, Speed Post, Ecom Express &amp; 30+ more.
            </p>
          </div>
        </div>

        {/* Bottom copyright */}
        <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div>
            &copy; {new Date().getFullYear()} Courier Search. All Rights Reserved. Built for All-India logistics enquiry.
          </div>
          <div className="flex items-center gap-4">
            <button onClick={onOpenPrivacy} className="hover:text-slate-400 transition cursor-pointer">
              Privacy
            </button>
            <span>•</span>
            <button onClick={onOpenTerms} className="hover:text-slate-400 transition cursor-pointer">
              Terms
            </button>
            <span>•</span>
            <button onClick={onOpenDisclaimer} className="hover:text-slate-400 transition cursor-pointer">
              Disclaimer
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
