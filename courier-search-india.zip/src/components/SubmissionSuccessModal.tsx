import React, { useState } from 'react';
import { ShipmentEnquiryPayload } from '../config/googleForm';
import { COURIER_DATABASE } from '../data/couriers';
import { CourierLogoBadge } from './CourierLogoBadge';
import {
  CheckCircle2,
  Clock,
  Copy,
  Check,
  Building2,
  Barcode,
  MapPin,
  Calendar,
  AlertTriangle,
  FileText,
  RotateCcw,
} from 'lucide-react';

interface SubmissionSuccessModalProps {
  data: ShipmentEnquiryPayload;
  onReset: () => void;
}

export const SubmissionSuccessModal: React.FC<SubmissionSuccessModalProps> = ({
  data,
  onReset,
}) => {
  const [copied, setCopied] = useState(false);

  const courier = COURIER_DATABASE.find((c) => c.id === data.courierId) || {
    id: 'other',
    name: data.courierCompany,
    brandColor: '#2563eb',
    badgeTextColor: '#ffffff',
    initials: data.courierCompany.slice(0, 2),
    category: 'other' as const,
    searchKeywords: [],
    sampleFormat: '',
  };

  const handleCopyRef = () => {
    navigator.clipboard.writeText(data.referenceId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/70 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Top green gradient bar */}
        <div className="h-2 bg-gradient-to-r from-emerald-500 via-teal-500 to-blue-500" />

        <div className="p-5 sm:p-7 overflow-y-auto">
          {/* Header icon and title */}
          <div className="text-center mb-6">
            <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3 shadow-inner">
              <CheckCircle2 size={36} strokeWidth={2.5} />
            </div>

            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-semibold mb-2">
              <Check size={13} strokeWidth={3} />
              Request Submitted Successfully
            </div>

            <h3 className="text-2xl font-black text-slate-900 tracking-tight">
              Enquiry Registered
            </h3>
            <p className="text-slate-600 text-sm mt-1 max-w-sm mx-auto">
              Thank you. Your shipment details have been received.
            </p>
          </div>

          {/* 24-Hour Review Notice Banner */}
          <div className="mb-5 p-3.5 rounded-xl bg-amber-50/90 border border-amber-200/80 flex items-start gap-3">
            <Clock className="text-amber-600 shrink-0 mt-0.5" size={18} />
            <div className="text-xs text-amber-900 leading-relaxed">
              <p className="font-semibold text-amber-950">
                Please allow up to 24 hours for your enquiry to be reviewed and updated.
              </p>
              <p className="mt-0.5 text-amber-800/90">
                Our support desk matches consignment logs with dispatch hubs to assist your inquiry.
              </p>
            </div>
          </div>

          {/* Reference Number Box */}
          <div className="p-3.5 mb-5 rounded-xl bg-slate-50 border border-slate-200 flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Enquiry Reference Number
              </span>
              <span className="font-mono text-base font-extrabold text-blue-700">
                {data.referenceId}
              </span>
            </div>
            <button
              onClick={handleCopyRef}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-medium bg-white border border-slate-300 text-slate-700 hover:bg-slate-100 transition shadow-2xs cursor-pointer"
            >
              {copied ? (
                <>
                  <Check size={13} className="text-emerald-600" />
                  <span className="text-emerald-700 font-semibold">Copied</span>
                </>
              ) : (
                <>
                  <Copy size={13} />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>

          {/* Submitted Details Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-4 space-y-3 text-xs mb-5 shadow-2xs">
            <div className="text-[11px] font-bold text-slate-400 uppercase tracking-wider pb-1 border-b border-slate-100 flex items-center justify-between">
              <span>Shipment Summary</span>
              <span className="text-emerald-600 font-semibold">Status: Under Review</span>
            </div>

            {/* Courier Company */}
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Building2 size={14} className="text-slate-400" />
                Courier Company:
              </span>
              <div className="flex items-center gap-2">
                <CourierLogoBadge courier={courier} size="sm" />
                <span className="font-bold text-slate-900">{data.courierCompany}</span>
              </div>
            </div>

            {/* Tracking ID */}
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 flex items-center gap-1.5">
                <Barcode size={14} className="text-slate-400" />
                Tracking ID:
              </span>
              <span className="font-mono font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded text-xs">
                {data.trackingId}
              </span>
            </div>

            {/* Shipment Location */}
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500 flex items-center gap-1.5">
                <MapPin size={14} className="text-slate-400" />
                Shipment Location:
              </span>
              <span className="font-semibold text-slate-900">{data.shipmentLocation}</span>
            </div>

            {/* Submitter */}
            <div className="flex items-center justify-between py-1">
              <span className="text-slate-500">Contact Person:</span>
              <span className="font-medium text-slate-800">{data.fullName} (+91 •••••••{data.mobileNumber.slice(-3)})</span>
            </div>

            {/* Submission Date */}
            <div className="flex items-center justify-between py-1 border-t border-slate-100 pt-2 text-[11px]">
              <span className="text-slate-400 flex items-center gap-1">
                <Calendar size={13} />
                Submitted on:
              </span>
              <span className="text-slate-500">{data.submittedAt}</span>
            </div>
          </div>

          {/* Realistic notice */}
          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/80 text-[11px] text-slate-500 leading-normal flex items-start gap-2 mb-6">
            <AlertTriangle size={15} className="text-slate-400 shrink-0 mt-0.5" />
            <p>
              <strong className="text-slate-700">Notice:</strong> This inquiry has been queued for verification. Keep your Reference Number safe for any future follow-up.
            </p>
          </div>

          {/* Primary Action Button */}
          <button
            onClick={onReset}
            className="w-full py-3.5 px-5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm tracking-wide shadow-md shadow-blue-600/20 transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-[0.99]"
          >
            <RotateCcw size={16} />
            <span>Submit Another Enquiry</span>
          </button>
        </div>
      </div>
    </div>
  );
};
