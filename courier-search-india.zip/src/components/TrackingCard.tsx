import React, { useState } from 'react';
import { CourierCompany, COURIER_DATABASE } from '../data/couriers';
import { CourierLogoBadge } from './CourierLogoBadge';
import { CourierSelectorModal } from './CourierSelectorModal';
import {
  User,
  Phone,
  Search,
  MapPin,
  Barcode,
  ChevronDown,
  CheckCircle2,
  AlertCircle,
  Loader2,
  ShieldCheck,
  Building2,
} from 'lucide-react';
import { submitShipmentEnquiry, ShipmentEnquiryPayload } from '../config/googleForm';

interface TrackingCardProps {
  onSuccess: (data: ShipmentEnquiryPayload) => void;
  preselectedCourierId?: string | null;
}

export const TrackingCard: React.FC<TrackingCardProps> = ({
  onSuccess,
  preselectedCourierId,
}) => {
  // Preselect courier if provided
  const [selectedCourier, setSelectedCourier] = useState<CourierCompany | null>(() => {
    if (preselectedCourierId) {
      return COURIER_DATABASE.find((c) => c.id === preselectedCourierId) || null;
    }
    return null;
  });

  // Update selectedCourier if preselectedCourierId changes
  React.useEffect(() => {
    if (preselectedCourierId) {
      const found = COURIER_DATABASE.find((c) => c.id === preselectedCourierId);
      if (found) {
        setSelectedCourier(found);
      }
    }
  }, [preselectedCourierId]);

  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [fullName, setFullName] = useState('');
  const [mobileNumber, setMobileNumber] = useState('');
  const [trackingId, setTrackingId] = useState('');
  const [shipmentLocation, setShipmentLocation] = useState('');

  // Status & Validation
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submissionStep, setSubmissionStep] = useState<string>('');

  // Validate Indian Mobile Number (10 digits starting with 6, 7, 8, 9)
  const validateMobile = (phone: string): boolean => {
    const cleaned = phone.replace(/\D/g, '');
    return /^[6-9]\d{9}$/.test(cleaned);
  };

  const handleMobileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '').slice(0, 10);
    setMobileNumber(value);
    if (errors.mobileNumber) {
      setErrors((prev) => ({ ...prev, mobileNumber: '' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!fullName.trim() || fullName.trim().length < 2) {
      newErrors.fullName = 'Please enter your full name';
    }

    if (!mobileNumber) {
      newErrors.mobileNumber = 'Please enter your 10-digit mobile number';
    } else if (!validateMobile(mobileNumber)) {
      newErrors.mobileNumber = 'Please enter a valid 10-digit Indian mobile number';
    }

    if (!selectedCourier) {
      newErrors.courier = 'Please select a courier company';
    }

    if (!trackingId.trim() || trackingId.trim().length < 3) {
      newErrors.trackingId = 'Please enter a valid Tracking ID / AWB Number';
    }

    if (!shipmentLocation.trim() || shipmentLocation.trim().length < 2) {
      newErrors.shipmentLocation = 'Please enter destination city or location';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateForm()) {
      return;
    }

    setIsSubmitting(true);
    setSubmissionStep('Verifying consignment details...');

    // Generate clean reference ID: e.g. ENQ-IN-938210
    const randomHex = Math.floor(100000 + Math.random() * 900000);
    const refId = `ENQ-IND-${randomHex}`;

    try {
      await new Promise((res) => setTimeout(res, 600));
      setSubmissionStep('Submitting shipment enquiry...');

      const payload: ShipmentEnquiryPayload = {
        referenceId: refId,
        fullName: fullName.trim(),
        mobileNumber: mobileNumber.trim(),
        courierCompany: selectedCourier!.name,
        courierId: selectedCourier!.id,
        trackingId: trackingId.trim().toUpperCase(),
        shipmentLocation: shipmentLocation.trim(),
        submittedAt: new Date().toLocaleString('en-IN', {
          dateStyle: 'medium',
          timeStyle: 'short',
        }),
        status: 'Received',
      };

      await submitShipmentEnquiry(payload);

      await new Promise((res) => setTimeout(res, 400));
      setIsSubmitting(false);
      onSuccess(payload);
    } catch (err) {
      console.error(err);
      setIsSubmitting(false);
      setErrors({ form: 'An unexpected error occurred. Please try again.' });
    }
  };

  return (
    <div
      id="track-card"
      className="w-full max-w-xl mx-auto bg-white/95 backdrop-blur-md rounded-2xl shadow-xl border border-slate-200/80 p-5 sm:p-7 relative transition-all"
    >
      {/* Decorative top accent */}
      <div className="absolute top-0 left-6 right-6 h-1.5 bg-linear-to-r from-blue-600 via-indigo-600 to-sky-500 rounded-t-full" />

      {/* Card Header */}
      <div className="mb-5 sm:mb-6 pt-1">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-700 flex items-center justify-center">
              <Search size={18} />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                Search Your Shipment
              </h2>
              <p className="text-xs text-slate-500">
                Official tracking directory &amp; enquiry assistance for all major couriers in India
              </p>
            </div>
          </div>
          <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-full border border-emerald-200">
            <ShieldCheck size={13} />
            Verified Portal
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4" noValidate>
        {/* ROW 1: Full Name & Mobile Number */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          {/* FULL NAME */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Full Name <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <User className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
              <input
                type="text"
                value={fullName}
                onChange={(e) => {
                  setFullName(e.target.value);
                  if (errors.fullName) setErrors((prev) => ({ ...prev, fullName: '' }));
                }}
                placeholder="Enter your full name"
                className={`w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 transition ${
                  errors.fullName ? 'border-rose-400 ring-1 ring-rose-300' : 'border-slate-300'
                }`}
              />
            </div>
            {errors.fullName && (
              <p className="mt-1 text-xs text-rose-600 flex items-center gap-1 font-medium">
                <AlertCircle size={12} /> {errors.fullName}
              </p>
            )}
          </div>

          {/* MOBILE NUMBER */}
          <div>
            <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
              Mobile Number <span className="text-rose-500">*</span>
            </label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 -translate-y-1/2 flex items-center gap-1 text-slate-500 text-xs font-semibold select-none border-r border-slate-200 pr-2">
                <span>+91</span>
              </div>
              <input
                type="tel"
                value={mobileNumber}
                onChange={handleMobileChange}
                placeholder="Enter 10-digit mobile number"
                className={`w-full pl-15 pr-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 transition ${
                  errors.mobileNumber ? 'border-rose-400 ring-1 ring-rose-300' : 'border-slate-300'
                }`}
              />
            </div>
            {errors.mobileNumber && (
              <p className="mt-1 text-xs text-rose-600 flex items-center gap-1 font-medium">
                <AlertCircle size={12} /> {errors.mobileNumber}
              </p>
            )}
          </div>
        </div>

        {/* ROW 2: COURIER COMPANY SELECTOR */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Courier Company <span className="text-rose-500">*</span>
          </label>
          <button
            type="button"
            onClick={() => setIsModalOpen(true)}
            className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-xl border text-left transition cursor-pointer ${
              selectedCourier
                ? 'bg-blue-50/70 border-blue-400 ring-1 ring-blue-400/40'
                : 'bg-slate-50 hover:bg-slate-100 border-slate-300'
            } ${errors.courier ? 'border-rose-400 ring-1 ring-rose-300' : ''}`}
          >
            {selectedCourier ? (
              <div className="flex items-center gap-3 min-w-0">
                <CourierLogoBadge courier={selectedCourier} size="sm" />
                <span className="font-bold text-slate-900 text-sm truncate">
                  {selectedCourier.name}
                </span>
                <span className="inline-flex items-center gap-0.5 text-xs text-emerald-700 font-semibold bg-emerald-100/80 px-2 py-0.5 rounded-md">
                  ✓ Selected
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2.5 text-slate-400 text-sm">
                <Building2 size={18} className="text-slate-400" />
                <span>Choose Courier Company</span>
              </div>
            )}
            <div className="flex items-center gap-1 text-slate-500 shrink-0 text-xs font-medium">
              <span className="hidden sm:inline">{selectedCourier ? 'Change' : 'Browse 40+'}</span>
              <ChevronDown size={16} />
            </div>
          </button>
          {errors.courier && (
            <p className="mt-1 text-xs text-rose-600 flex items-center gap-1 font-medium">
              <AlertCircle size={12} /> {errors.courier}
            </p>
          )}
        </div>

        {/* ROW 3: TRACKING ID / AWB NUMBER */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Tracking ID / AWB Number <span className="text-rose-500">*</span>
          </label>
          <div className="relative">
            <Barcode className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
            <input
              type="text"
              value={trackingId}
              onChange={(e) => {
                setTrackingId(e.target.value);
                if (errors.trackingId) setErrors((prev) => ({ ...prev, trackingId: '' }));
              }}
              placeholder="Enter Tracking ID / AWB Number"
              className={`w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm font-mono uppercase text-slate-900 placeholder:text-slate-400 placeholder:font-sans focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 transition ${
                errors.trackingId ? 'border-rose-400 ring-1 ring-rose-300' : 'border-slate-300'
              }`}
            />
          </div>
          {selectedCourier && (
            <p className="mt-1 text-[11px] text-slate-500">
              Expected format: <span className="font-mono text-slate-700">{selectedCourier.sampleFormat}</span>
            </p>
          )}
          {errors.trackingId && (
            <p className="mt-1 text-xs text-rose-600 flex items-center gap-1 font-medium">
              <AlertCircle size={12} /> {errors.trackingId}
            </p>
          )}
        </div>

        {/* ROW 4: SHIPMENT LOCATION */}
        <div>
          <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
            Shipment Location <span className="text-rose-500">*</span>
          </label>
          <div className="relative">
            <MapPin className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={17} />
            <input
              type="text"
              value={shipmentLocation}
              onChange={(e) => {
                setShipmentLocation(e.target.value);
                if (errors.shipmentLocation) setErrors((prev) => ({ ...prev, shipmentLocation: '' }));
              }}
              placeholder="Enter city or shipment location"
              className={`w-full pl-10 pr-3.5 py-2.5 bg-slate-50 border rounded-xl text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600 transition ${
                errors.shipmentLocation ? 'border-rose-400 ring-1 ring-rose-300' : 'border-slate-300'
              }`}
            />
          </div>
          {errors.shipmentLocation && (
            <p className="mt-1 text-xs text-rose-600 flex items-center gap-1 font-medium">
              <AlertCircle size={12} /> {errors.shipmentLocation}
            </p>
          )}
        </div>

        {/* Form level error */}
        {errors.form && (
          <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-700 font-medium flex items-center gap-2">
            <AlertCircle size={16} className="shrink-0" />
            <span>{errors.form}</span>
          </div>
        )}

        {/* SUBMIT BUTTON */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full py-3.5 px-6 rounded-xl bg-gradient-to-r from-blue-600 via-indigo-600 to-blue-700 hover:from-blue-700 hover:to-indigo-700 text-white font-extrabold text-sm sm:text-base tracking-wide shadow-lg shadow-blue-600/30 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-center gap-2 disabled:opacity-75 disabled:cursor-not-allowed"
          >
            {isSubmitting ? (
              <>
                <Loader2 size={18} className="animate-spin" />
                <span>{submissionStep || 'Submitting shipment enquiry...'}</span>
              </>
            ) : (
              <>
                <Search size={19} />
                <span>SEARCH COURIER</span>
              </>
            )}
          </button>
        </div>

        {/* Helper privacy hint */}
        <p className="text-[11px] text-center text-slate-500 pt-1">
          🔒 Your contact details are safely encrypted and strictly used for shipment enquiry assistance.
        </p>
      </form>

      {/* Courier Selection Modal */}
      <CourierSelectorModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        selectedCourier={selectedCourier}
        onSelect={(courier) => {
          setSelectedCourier(courier);
          if (errors.courier) {
            setErrors((prev) => ({ ...prev, courier: '' }));
          }
        }}
      />
    </div>
  );
};
