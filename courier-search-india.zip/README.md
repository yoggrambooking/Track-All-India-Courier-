# Courier Search – All India Courier Tracking & Shipment Enquiry

A modern, production-grade, and independent shipment enquiry & courier tracking directory portal designed for logistics and e-commerce shipments across India.

---

## 🌟 Key Features

1. **Powerful Searchable Courier Selector**:
   - One unified search interface covering 40+ domestic & international carriers (Delhivery, Blue Dart, DTDC, India Post, Speed Post, Amazon, Flipkart/Ekart, Ecom Express, XpressBees, Shadowfax, DHL, FedEx, etc.).
   - Instant live search filtering (e.g. typing `"ama"` brings up Amazon, `"flip"` brings up Flipkart, `"del"` brings up Delhivery).
   - Category filtering (Most Popular, E-Commerce, Express & Air, Heavy Cargo, International).
   - In-field selected state display: `[Logo] Company Name ✓`.

2. **Main Tracking Card (`Search Your Shipment`)**:
   - Full Name
   - 10-Digit Mobile Number (Indian mobile validation)
   - Courier Company (searchable modal selector)
   - Tracking ID / AWB Number (with per-carrier format hints)
   - Shipment Location / Destination City
   - "SEARCH COURIER" action button

3. **Compliant Submission Flow & Honest Confirmation**:
   - Submits consignment enquiry with reference number generation (`ENQ-IND-XXXXXX`).
   - Clear and honest confirmation notice: *"Please allow up to 24 hours for your enquiry to be reviewed and updated."*
   - Copy reference ID, submission details summary, and local history tracking.
   - Zero misleading "courier is on the way" fake animations.

4. **Independent Platform & Compliance**:
   - Prominent non-affiliation disclaimer:
     > *"This website is an independent shipment enquiry platform and is not affiliated with, endorsed by, or officially connected with the courier, logistics or e-commerce companies listed on this website."*
   - Comprehensive Privacy Policy, Terms & Conditions, and Contact desk modals.

5. **Google Forms & Google Sheets Ready**:
   - Clean, isolated configuration in `src/config/googleForm.ts`.
   - Direct form action URL parameter mapping or embed iframe mode.

6. **SEO & Mobile-First**:
   - Tailored title: *"All India Courier Tracking Search & Shipment Enquiry | All India"*
   - OpenGraph and Twitter cards, Schema.org WebApplication JSON-LD, `robots.txt`, and `sitemap.xml`.
   - 100% responsive across mobile (360px–414px), tablet (768px), and desktop (1024px–1440px+).

---

## 🚀 How to Run Locally

```bash
# 1. Install dependencies
npm install

# 2. Run local development server
npm run dev

# 3. Build for production (Cloudflare Pages / GitHub Pages / Vercel)
npm run build
```

The production output will be generated in the `dist` folder.

---

## 📋 Google Forms & Google Sheets Integration

1. Go to [Google Forms](https://forms.google.com) and create a form with 5 short-answer questions:
   - `Full Name`
   - `Mobile Number`
   - `Courier Company`
   - `Tracking ID / AWB Number`
   - `Shipment Location`
2. Under the **Responses** tab, click **Link to Sheets** to create a Google Spreadsheet that receives submissions automatically.
3. Open `src/config/googleForm.ts` and set your Google Form URL:
   ```typescript
   export const GOOGLE_FORM_CONFIG = {
     GOOGLE_FORM_URL: "https://docs.google.com/forms/d/e/.../formResponse",
     // ...
   };
   ```

---

## ☁️ Deploying to Cloudflare Pages via GitHub

1. Push this repository to **GitHub**.
2. Go to the [Cloudflare Dashboard](https://dash.cloudflare.com/) → **Compute (Workers & Pages)** → **Create application** → **Pages** → **Connect to Git**.
3. Select your repository.
4. Configure the build settings:
   - **Framework preset**: `Vite`
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
5. Click **Save and Deploy**. Your live website will be live worldwide on Cloudflare's edge CDN!
